#ifndef SERIAL_PORT_H
#define SERIAL_PORT_H

int SerialOpen(int* pFd);
void SerialClose(int* pFd);

#endif // SERIAL_PORT_H
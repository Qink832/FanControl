#include "FanController.h"
#include "json.hpp"
#include "dcmi_interface_api.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/file.h>
#include <syslog.h>
#include <iostream>
#include <fstream>
#include <filesystem>

using json = nlohmann::json;
using namespace std;

GlobalParams            g_params;
std::shared_mutex       params_mutex;

const string DEFAULT_JSON = R"(
    {
        "mode": true
    }
)";

bool CreateDefaultFile(string filePath)
{
    int ret = -1;
    int fd = -1;

    // 写锁
    fd = open(filePath.data(), O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
    IF_COND_FAIL(fd != -1, (string("[ERROR] CreateDefaultFile: Failed to get fd")+filePath).data(), return false);

    ret = flock(fd, LOCK_EX);
    IF_COND_FAIL(ret != -1, "[ERROR] CreateDefaultFile: Failed to lock file, LOCK_EX", return false);

    // 以写入模式创建文件
    ofstream outfile(filePath);
    IF_COND_FAIL(outfile.is_open(), "[ERROR] CreateDefaultFile: Fail to create /etc/FanControlParams.json", return false);
    
    outfile << DEFAULT_JSON;
    outfile.close();

    // 解锁
    flock(fd, LOCK_UN);
    close(fd);
    
    return true;
}

void* ParamsListen(void* arg)
{
    int         ret = -1;
    int         fd = -1;
    json        root;

    while(true)
    {
        // 读锁
        fd = open(MODE_FILE_PATH, O_WRONLY, S_IRUSR | S_IWUSR);
        IF_COND_FAIL(fd != -1, (string("[ERROR] ParamsListen : Failed to get fd")+MODE_FILE_PATH).data(), continue;);
        
        ret = flock(fd, LOCK_SH);
        IF_COND_FAIL(ret != -1, "[ERROR] ParamsListen : Failed to lock file, LOCK_SH", continue;);

        // 解析 json
        ifstream  file(MODE_FILE_PATH);
        IF_COND_FAIL(file.is_open(), "[ERROR] ParamsListen : Failed to open file", continue;);

        file >> root;
        
        if(root["mode"].is_null() || !root["mode"].is_boolean())
        {
            syslog(LOG_INFO, "[ERROR] ParamsListen : Failed to parse json file, mode is null or not bool type. Create default json file.");
            // cout << "[ERROR] ParamsListen : Failed to parse json file, mode is null or not bool type. Create default json file." << endl;
            CreateDefaultFile(MODE_FILE_PATH);
            continue;
        }
        // else if(root["card_fan_bus_id_list"].is_null() || !root["card_fan_bus_id_list"].is_array())
        // {
        //     syslog(LOG_INFO, "[ERROR] ParamsListen : Failed to parse json file, card_fan_bus_id_list is null or not array type. Create default json file.");
        //     // cout << "[ERROR] ParamsListen : Failed to parse json file, card_fan_bus_id_list is null or not array type. Create default json file." << endl;
        //     CreateDefaultFile(MODE_FILE_PATH);
        //     continue;
        // }

        g_params.update(root["mode"]);

        //解锁
        flock(fd, LOCK_UN);
        close(fd);

        //重置变量，间隔1s
        root.clear();
        ret = fd = -1;
        sleep(1);
    }

    return NULL;
}

int main()
{
    int                     ret = -1;
    pthread_t               paramsTid;

    // 检查配置文件是否存在，不存在就创建默认的
    if(!filesystem::exists(MODE_FILE_PATH))
    {
        IF_COND_FAIL(CreateDefaultFile(MODE_FILE_PATH), "CreateDefaultFile fail, process exit", return -1);
    }

    // 创建线程，不断更新 g_params
    pthread_create(&paramsTid, NULL, ParamsListen, NULL);
    pthread_detach(paramsTid);

    bool                    resetFlag = false;
    SysController           sysCtrl;
    int                     cardNum = 0;
    int                     cardList[8] = {0};
    CardController          cardCtrl;

    
    IF_COND_FAIL(cardCtrl.Init(), "CardController.Init() fail, process exit", return -1);

    while(true)
    {
        if(g_params.getMode())
        {
            if(resetFlag)
            {
                // 打开串口
                sysCtrl.Restart();
                cardCtrl.Restart();

                resetFlag = false;
            }

            sysCtrl.SetPwm();
            cardCtrl.SetPwm();
        }
        else
        {
            resetFlag = true;

            syslog(LOG_INFO, "[INFO] Mode is Manual.");
            // cout << "[INFO] Mode is Manual." << endl;
        }

        sleep(5);
    }

    return 0;
}
#!/bin/bash

cp -v ./aaeon_sio.ko /lib/modules/5.15.0-119-generic/
cp -v ./ai_fan_control.service /etc/systemd/system/ai_fan_control.service
cp -v ./fan_test /usr/local/bin/fan_test
cp -v ./aifan_ctrl.sh /usr/local/bin/aifan_ctrl.sh
echo "aaeon_sio" >> /etc/modules-load.d/modules.conf
systemctl enable ai_fan_control.service
depmod -a
sync


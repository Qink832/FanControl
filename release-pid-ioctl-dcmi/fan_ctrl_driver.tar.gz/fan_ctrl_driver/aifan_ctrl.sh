#!/bin/bash

if [ -e /var/mini_upgraded ]; then
   echo ""
fi

fan_test set 2 2 100 &
fan_test set 3 2 100 &
